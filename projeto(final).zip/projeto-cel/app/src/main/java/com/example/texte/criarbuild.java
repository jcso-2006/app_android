package com.example.texte;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class criarbuild extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_criarbuild);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button druida = findViewById(R.id.button2); // Certifique-se de que o ID está correto

        // Define um listener de clique no botão
        druida.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Altera a cor de fundo do botão ao ser clicado
                druida.setBackgroundColor(getResources().getColor(R.color.nova_cor));
            }
        });
        Button  necro = findViewById(R.id.button3);
        necro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Altera a cor de fundo do botão ao ser clicado
                necro.setBackgroundColor(getResources().getColor(R.color.nova_cor));
            }
        });
        Button  barbaro = findViewById(R.id.button4);
        barbaro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Altera a cor de fundo do botão ao ser clicado
                barbaro.setBackgroundColor(getResources().getColor(R.color.nova_cor));
            }
        });
        Button  rogue = findViewById(R.id.button5);
        rogue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Altera a cor de fundo do botão ao ser clicado
                rogue.setBackgroundColor(getResources().getColor(R.color.nova_cor));
            }
        });

        Button  mago = findViewById(R.id.button7);
        mago.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Altera a cor de fundo do botão ao ser clicado
                mago.setBackgroundColor(getResources().getColor(R.color.nova_cor));
            }
        });

    }
    public void voltarActivity(View view){
        finish();

    }

}