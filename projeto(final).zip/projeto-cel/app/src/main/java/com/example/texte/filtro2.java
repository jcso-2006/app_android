package com.example.texte;

import android.widget.Button;
import android.os.Bundle;
import android.view.View; // Importa a classe View
import android.content.Intent; // Importa a classe Intent
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class filtro2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_filtro2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.filtro2), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Button Bmeta = findViewById(R.id.meta); // Certifique-se de que o ID está correto

        // Define um listener de clique no botão
        Bmeta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Altera a cor de fundo do botão ao ser clicado
                Bmeta.setBackgroundColor(getResources().getColor(R.color.nova_cor));
            }
        });
        Button  Bstart = findViewById(R.id.start);
        Bstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Altera a cor de fundo do botão ao ser clicado
                Bstart.setBackgroundColor(getResources().getColor(R.color.nova_cor));
            }
        });
        Button  Bendgame = findViewById(R.id.endgame);
        Bendgame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Altera a cor de fundo do botão ao ser clicado
                Bendgame.setBackgroundColor(getResources().getColor(R.color.nova_cor));
            }
        });



    }
    public void abrirHomeActivity(View view) {
        Intent intent = new Intent(this, criarbuild.class);
        startActivity(intent);
    }


}